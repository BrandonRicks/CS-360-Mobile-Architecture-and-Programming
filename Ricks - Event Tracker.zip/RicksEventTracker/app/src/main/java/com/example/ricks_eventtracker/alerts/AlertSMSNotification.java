package com.example.ricks_eventtracker.alerts;

import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.example.ricks_eventtracker.eventsmain.EventsListActivity;
import com.example.ricks_eventtracker.R;

/*
 *  Name: Brandon Ricks
 *  Course: CS-360 Mobile Architecture & Programming
 *  Date: 02/18/2022
 *  Description: Event Tracker app that allows user to create or log into account,
 *               storing of account info, and CRUD functionality for events.
 *               Account info and events are stored in SQLite databases.
 */

/*
 *  AlertSMSNotification class for popup alert on request of SMS notifications
 */

public class AlertSMSNotification {

    public static AlertDialog doubleButton(final EventsListActivity context) {

        // Builder class for dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.alert_sms_title)
                .setIcon(R.drawable.button_sms)
                .setCancelable(false)
                .setMessage(R.string.alert_sms_msg)
                .setPositiveButton(R.string.alert_sms_enable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS alerts have been enabled", Toast.LENGTH_LONG).show();
                    EventsListActivity.AllowSendSMS();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.alert_sms_disable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS alerts have been disabled", Toast.LENGTH_LONG).show();
                    EventsListActivity.DenySendSMS();
                    dialog.cancel();
                });

        // AlertDialog object return
        return builder.create();
    }
}
