package com.example.ricks_eventtracker.alerts;

import androidx.appcompat.app.AlertDialog;

import com.example.ricks_eventtracker.eventsmain.EventsListActivity;
import com.example.ricks_eventtracker.R;

/*
 *  Name: Brandon Ricks
 *  Course: CS-360 Mobile Architecture & Programming
 *  Date: 02/18/2022
 *  Description: Event Tracker app that allows user to create or log into account,
 *               storing of account info, and CRUD functionality for events.
 *               Account info and events are stored in SQLite databases.
 */

/*
 *  AlertDeleteAllEvents class for popup alert on delete all
 */

public class AlertDeleteAllEvents {

    public static AlertDialog doubleButton(final EventsListActivity context) {

        // Builder class for dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.alert_delete_title)
                .setIcon(R.drawable.button_delete_all)
                .setCancelable(false)
                .setMessage(R.string.alert_delete_msg)
                .setPositiveButton(R.string.alert_delete_dialog_yes_button, (dialog, arg1) -> {
                    EventsListActivity.YesDeleteEvents();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.alert_delete_dialog_no_button, (dialog, arg1) -> {
                    EventsListActivity.NoDeleteEvents();
                    dialog.cancel();
                });

        // AlertDialog object return
        return builder.create();
    }
}
